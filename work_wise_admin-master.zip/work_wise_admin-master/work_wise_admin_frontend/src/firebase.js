import { initializeApp } from "firebase/app";

const firebaseConfig = {
    apiKey: "AIzaSyCBfeTOavkHVByrQjn0iUCEKhZ9OhrlJis",
    authDomain: "work-wise-95930.firebaseapp.com",
    databaseURL: "https://work-wise-95930-default-rtdb.firebaseio.com",
    projectId: "work-wise-95930",
    storageBucket: "work-wise-95930.appspot.com",
    messagingSenderId: "729928342267",
    appId: "1:729928342267:web:c0b5eba4148386292b6e5e",
    measurementId: "G-MRPWKTS0WX"
};

// Initialize Firebase
export const firebase = initializeApp(firebaseConfig);