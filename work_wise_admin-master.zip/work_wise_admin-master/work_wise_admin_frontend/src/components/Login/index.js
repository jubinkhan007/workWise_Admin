import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom';
import './login.css'
import Axios from "axios"
import { host } from '../../host'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import swal from 'sweetalert';
import { firebase } from '../../firebase'
import { getAuth, signInWithPhoneNumber, RecaptchaVerifier } from "firebase/auth";

const Index = () => {
    const [admin_email, setAdmin_email] = useState('')
    const [admin_password, setAdmin_password] = useState('')
    const [checkbox, setCheckbox] = useState(false)
    const [viewOtpForm, setViewOtpForm] = useState(false);
    const [OTP, setOTP] = useState('')
    const auth = getAuth(firebase)
    const navigate = useNavigate();

    useEffect(() => {
        window.recaptchaVerifier = new RecaptchaVerifier('recaptcha-container', {
            'size': 'invisible',
            'callback': (response) => {
                // reCAPTCHA solved, allow signInWithPhoneNumber.
                console.log("Captcha Resolved");
                //onSignInSubmit()
            }
        }, auth);
    }, [])

    const handleOTPSubmit = (e) => {
        e.preventDefault()

        try {
            confirmationResult.confirm(OTP).then((result) => {
                // User signed in successfully.
                //console.log(result)
                setOTP('')
                const data = { admin_email, admin_password }
                Axios.post(`${host}/api/signin`, data)
                    .then((response) => {
                        //console.log(response.data.token.token)
                        localStorage.setItem('token',JSON.stringify(response.data.token.token))
                        navigate('/')
                        swal(`${response.data.message}`, "", "success")
                    })
                    .catch(err => console.log(err))
                // ...
            }).catch((error) => {
                // User couldn't sign in (bad verification code?)
                // ...
                alert(error.message);
            });
        } catch (e) {
            console.log(e)
        }
    }

    const notify = (phoneNo) => {
        const phoneNumber = phoneNo.split("")
        toast(`Send OTP to the +8801XXXXXX${phoneNumber[11]}${phoneNumber[12]}${phoneNumber[13]}!!!`, {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
        });
    }

    const handleformSubmit = (e) => {
        e.preventDefault();
        const data = { admin_email, admin_password }
        //OTP SECTION
        let phone_number = "+880"
        const appVerifier = window.recaptchaVerifier;

        try {
            Axios.post(`${host}/api/phonono`, data)
                .then(result => {
                    //get phoneNo
                    const phoneNo = phone_number.concat(result.data.phoneNo)
                    console.log(phoneNo)
                    //  SEND OTP
                    signInWithPhoneNumber(auth, phoneNo, appVerifier)
                        .then((confirmationResult) => {
                            // SMS sent. Prompt user to type the code from the message, then sign the
                            // user in with confirmationResult.confirm(code).
                            //alert("otp sent");
                            notify(phoneNo)
                            setViewOtpForm(true);
                            window.confirmationResult = confirmationResult;
                            // ...
                        })
                        .catch((error) => {
                            // Error; SMS not sent
                            // ...
                            alert(error.message);
                        })
                })
                .catch(err => console.log(err))

        } catch (error) {
            console.log(error)
        }
    }


    return (
        <>
            <div className="container">
                <div id="recaptcha-container"></div>
                <div className="d-flex justify-content-center h-100">
                    <div className="card">
                        <div className="card-header">
                            <h3>{viewOtpForm ? "Confirm OTP" : " Sign In"}</h3>
                            <div className="d-flex justify-content-end social_icon">
                                {/* <span><i className="fab fa-facebook-square"></i></span>
                            <span><i className="fab fa-google-plus-square"></i></span>
                            <span><i className="fab fa-twitter-square"></i></span> */}
                            </div>
                        </div>
                        <div className="card-body">
                            <form onSubmit={viewOtpForm ? handleOTPSubmit : handleformSubmit} >
                                {
                                    viewOtpForm ? null : <div className="input-group form-group mb-3"  >

                                        <div className="input-group-prepend">
                                            <label htmlFor="admin_email" style={{ height: "100%" }}>
                                                <span className="input-group-text"><i className="fas fa-user"></i></span>
                                            </label>
                                        </div>
                                        <input
                                            type="email"
                                            id="admin_email"
                                            className="form-control"
                                            placeholder="email"
                                            value={admin_email}
                                            onChange={(e) => setAdmin_email(e.target.value)}
                                        />
                                    </div>
                                }
                                {
                                    viewOtpForm ?
                                        <div className="input-group form-group my-3">
                                            <div className="input-group-prepend">
                                                <label htmlFor="otp" style={{ height: "100%" }}>
                                                    <span className="input-group-text"><i className="fas fa-key"></i></span>
                                                </label>
                                            </div>
                                            <input
                                                type="number"
                                                id="otp"
                                                className="form-control"
                                                placeholder="Enter your OTP"
                                                value={OTP}
                                                onChange={(e) => setOTP(e.target.value)}
                                            />
                                        </div>
                                        :
                                        <div className="input-group form-group mb-3">
                                            <div className="input-group-prepend">
                                                <label htmlFor="admin_password" style={{ height: "100%" }}>
                                                    <span className="input-group-text"><i className="fas fa-key"></i></span>
                                                </label>
                                            </div>
                                            <input
                                                type="password"
                                                id="admin_password"
                                                className="form-control"
                                                placeholder="password"
                                                value={admin_password}
                                                onChange={(e) => setAdmin_password(e.target.value)}
                                            />
                                        </div>
                                }
                                {
                                    viewOtpForm ? null : <div className="row align-items-center remember  mb-4">
                                        <label htmlFor="checkbox" >
                                            <input
                                                type="checkbox"
                                                id='checkbox'
                                                defaultChecked={checkbox}
                                                onChange={() => {
                                                    checkbox ? setCheckbox(false) : setCheckbox(true)
                                                }}
                                            />
                                            Remember Me
                                        </label>
                                    </div>
                                }

                                {
                                    viewOtpForm ?
                                        <div className="form-group my-3">
                                            <button className="btn float-end login_btn">Confirm</button>
                                        </div>
                                        :
                                        <div className="form-group">
                                            <button className="btn float-end login_btn">Login</button>
                                        </div>
                                }

                            </form>
                        </div>
                        <div className="card-footer">
                            {/* <div className="d-flex justify-content-center links">
                            Don't have an account?<a href="#">Sign Up</a>
                        </div> */}
                            <div className="d-flex justify-content-center" style={{ color: "#FFC312" }}>
                                Forgot your password?
                                <a href="#">&nbsp; Click here</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <ToastContainer />
        </>
    )
}

export default Index
