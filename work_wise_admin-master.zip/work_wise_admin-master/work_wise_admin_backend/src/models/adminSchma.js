const mongoose = require('mongoose')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')


const ADMIN_SCHMA = new mongoose.Schema({
    admin_firstName: {
        type: String,
        required: true,
        trim: true,
        minLength: 3,
        maxLength: 30
    },
    admin_lastName: {
        type: String,
        required: true,
        trim: true,
        minLength: 3,
        maxLength: 30
    },
    admin_email: {
        type: String,
        required: true,
        trim: true,
        unique: true,
    },
    admin_phoneno: {
        type: Number,
        required: true,
        unique: true,
        trim: true,
        minLength: 11,
        maxLength: 14
    },
    admin_avatar:{
        type: String,
    },
    admin_coverImg:{
        type: String,
    },
    admin_date_of_birth: {
        type: String,
        required: true,
        trim: true,
    },
    admin_NID: {
        type: Number,
        required: true,
        unique: true,
        trim: true,
        minLength: 10,
        maxLength: 25
    },
    admin_hashpassword: {
        type: String,
        required: true,
        trim: true,
    },
    admin_role: {
        type: String,
        enum: ["SUPER_ADMIN", "MANAGER", "PROVIDER_MANAGER", "USER_MANAGER"],
        default: "SUPER_ADMIN"
    },

    tokens: [
        {
            token: {
                type: String,
                required: true
            },
            user: {
                name: {
                    type: String
                },
                email: {
                    type: String
                },
                role: {
                    type: String
                },
                phoneNo: {
                    type: Number
                },
                date: {
                    type: Date,
                    default: Date.now
                }
            }
        }
    ]
}, {
    timestamps: true
})

ADMIN_SCHMA.virtual("admin_password")
    .set(function (admin_password) {
        this.admin_hashpassword = bcrypt.hashSync(admin_password, 12)
    })


ADMIN_SCHMA.methods = {
    authenticate: async function (admin_password) {
        return await bcrypt.compare(admin_password, this.admin_hashpassword)
    },
    generateToken: async function () {
        const key = process.env.SECRECT_KEY
        const token = jwt.sign({ _id: this._id,admin_role: this.admin_role,admin_phoneno: this.admin_phoneno }, key, { expiresIn: "2d" })
        const fullName =this.admin_firstName.concat(" "+this.admin_lastName)
        this.tokens = this.tokens.concat({
            token: token,
            user: {
                name: fullName,
                email: this.admin_email,
                role: this.admin_role,
                phoneNo: this.admin_phoneno
            }
        })
        const length=this.tokens.length
        await this.save()
        return this.tokens[length-1]
    }
}


module.exports = mongoose.model("WORK_WISE_ADMIN", ADMIN_SCHMA)
