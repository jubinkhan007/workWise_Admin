const mongoose = require('mongoose')

const DB = process.env.DATABASE
const DB2 = process.env.DATABASE2

mongoose.connect(DB2, {
    useNewUrlParser: true,
    useCreateIndex: true,
    useUnifiedTopology: true,
    useFindAndModify: false
})
    .then(() => {
        console.log("MongoDB Connection successfull");
    })
    .catch(err => {
        console.log(err)
    })