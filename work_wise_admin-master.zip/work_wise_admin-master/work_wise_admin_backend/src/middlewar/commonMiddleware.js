const jwt = require('jsonwebtoken')

exports.verifyUser = (req, res, next) => {
    try {
        const token = req.headers.authorization.split(" ")[1];
        const admin = jwt.verify(token, process.env.SECRECT_KEY)
        req.admin = admin
        next()
    } catch (e) {
        console.log(e)
    }

}