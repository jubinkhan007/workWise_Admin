const express = require('express')
const router = express.Router()
const {verifyUser}=require("../middlewar/commonMiddleware")
const { updateProfile,getProfileData} = require('../controlers/adminEditProfile/editProfile')
// const {
//     validationRequestSignup,
//     isRequestValidated,
//     validationRequestSignin,
// } = require('../validators/authValidation')


router.get('/getProfileData',verifyUser,getProfileData)
router.post('/updateProfile',verifyUser,updateProfile)




module.exports = router