const express = require('express')
const router = express.Router()
const {verifyUser}=require("../middlewar/commonMiddleware")
const { signup, signin,phonono,signout} = require('../controlers/adminAuth/adminControler')
const {
    validationRequestSignup,
    isRequestValidated,
    validationRequestSignin,
} = require('../validators/authValidation')



router.post('/signup',signup)
router.post('/signin',signin)
router.post('/phonono',phonono)
router.delete('/signout',signout)
// router.post('/signin',/*  validationRequestSignin, isRequestValidated, */ signin)

// router.post('/signup',/*  validationRequestSignup, isRequestValidated, */ signup)

// router.post('/profile', verifyUser, (req, res) => {
//     res.status(200).json({ message: 'profile' })
// })


module.exports = router