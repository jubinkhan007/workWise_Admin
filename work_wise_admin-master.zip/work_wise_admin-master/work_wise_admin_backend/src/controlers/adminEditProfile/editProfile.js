const Admin = require('../../models/adminSchma')

//  getProfileData
exports.getProfileData = async (req, res) => {
    console.log("getProfileData")
    const admin = req.admin
    try {
        const query = Admin.findOne({ _id: admin._id }).select({
            "admin_email": 1,
            "admin_firstName": 1,
            "admin_phoneno": 1,
            "admin_lastName": 1
        })
        query.exec(function (err, someValue) {
            if (err) return console.log(err);
            console.log(someValue);
            res.send(someValue);
        });
    } catch (err) {
        console.log(err)
    }

}

//  updateProfile
exports.updateProfile = async (req, res) => {
    const admin = req.admin
    const { admin_firstName ,admin_lastName} = req.body
    try {
        const data = await Admin.findOneAndUpdate(
            {
                _id: admin._id
            },
            {
                $set: {
                    admin_firstName ,admin_lastName
                }
            }, { new: true })
        console.log(data);
    } catch (err) {
        console.log(err)
    }

}

