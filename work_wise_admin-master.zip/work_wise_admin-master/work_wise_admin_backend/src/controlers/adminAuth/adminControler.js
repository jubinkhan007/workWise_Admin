const Admin = require('../../models/adminSchma')

//signup
exports.signup = async (req, res) => {
    const {
        admin_firstName,
        admin_lastName,
        admin_email,
        admin_phoneno,
        admin_date_of_birth,
        admin_NID,
        admin_password
    } = req.body

    try {
        const adminExist = await Admin.findOne({ admin_email })
        console.log(adminExist);
        if (adminExist != null) {
            return res.status(422).json({ message: "User Already Exist!!!" })
        }
        const _admin = new Admin({
            admin_firstName,
            admin_lastName,
            admin_email,
            admin_phoneno,
            admin_date_of_birth,
            admin_NID,
            admin_password
        })
        await _admin.save()
        return res.status(201).json({ message: "User Registretion Successfull!!!" })
    } catch (error) {
        return res.status(404).json({ message: error })
    }
}

// fetch phone_number

exports.phonono = async (req, res) => {
    const { admin_email, admin_password } = req.body

    try {
        if (!admin_email || !admin_password) {
            return res.status(400).json({
                message: "Something went wrong!!!"
            })

        } else {
            const adminExist = await Admin.findOne({ admin_email })
            if (adminExist == null) {
                console.log(null);
                return res.status(404).json({ message: "Invalid Action!!!" })
            } else {
                const checkpass = await adminExist.authenticate(admin_password)
                console.log(checkpass)
                if (checkpass) {
                    return res.status(200).json({
                        phoneNo: adminExist.admin_phoneno
                    })
                } else {
                    return res.status(400).json({ message: "Invalid Action!!!" })
                }
            }
        }
    } catch (error) {
        return res.status(400).json({ message: error })
    }
}


//signin
exports.signin = async (req, res) => {
    const { admin_email, admin_password } = req.body

    try {
        if (!admin_email || !admin_password) {
            return res.status(400).json({
                message: "Invalid Action!!!"
            })

        } else {
            const adminExist = await Admin.findOne({ admin_email })
            if (adminExist == null) {
                console.log(null);
                return res.status(404).json({ message: "Invalid Action!!!" })
            } else {
                const checkpass = await adminExist.authenticate(admin_password)
                console.log(checkpass)
                if (checkpass) {
                    const token = await adminExist.generateToken()
                    console.log(token)
                    return res.status(200).json({
                        token: token,
                        message: "Login Succesfull!!!"
                    })
                } else {
                    return res.status(400).json({ message: "Invalid Action!!!" })
                }
            }
        }
    } catch (error) {
        return res.status(400).json({ message: error })
    }
}

exports.signout = async (req, res) => {

    const { authorization } = req.headers
    const logout = await Admin.updateOne(
        {
            "tokens.token": authorization
        },
        {
            $pull: { tokens: { token: authorization } }
        }
    )
    if(logout.nModified===1){
        return res.status(200).json({message: "Logout Successfull!!!"})
    }else{
        return res.status(200).json({message: "Not A Valid Request"})
    }
}

