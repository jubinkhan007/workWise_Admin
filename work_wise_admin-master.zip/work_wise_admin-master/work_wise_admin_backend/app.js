const express=require('express')
const app = express()
const cors = require('cors')
const dotenv = require('dotenv')
const compression= require("compression")
const router = require('./src/routes/auth')
const editProfilerouter = require('./src/routes/adminEditProfile')

dotenv.config({path:"./.env"})

const port=process.env.PORT

//mongodb Database
require('./src/db/connectMongoose')

//middleware
app.use(cors())
app.use(express.json())
app.use(compression())
app.use('/api',router)
app.use('/api/v1',editProfilerouter)



app.listen(port,()=>{
    console.log(`Listening to the port : ${port} `)
})